=== Paperglee ===
Contributors: valentinecomms
Tags: paper.li, content marketing
Requires at least: 3.0.1
Tested up to: 3.7.1
Stable Tag: trunk

== Short Description ==

Paperglee is a plugin for paper.li It converts paper.li content to SEO-rich posts and drives loads of inbound traffic.

== Description ==

5 minute setup: Just download, install and add a paper ID!
More options: Post any time, with any title, and any link!
Custom publishing: Create your own unique content categories!
SEO rich: Drive targeted traffic and social interactions!
Brand smart: Engage visitors with your own menus and forms!
Responsive: Looks and works great on tablets and smartphones!

Paperglee lets you post directly to your own web site, in your WordPress theme, beside your calls to action. You can schedule posts for whenever you want, and as often as you want. 
With Paperglee, you can also create custom content categories and unique web urls at yourname.com You can even add keywords and tags to help search engines find your content, and highlight your best content.
Paperglee is built to automatically integrate with your unique WordPress theme. It will look, act and feel exactly like the rest of your web site.

== Installation ==

1. Upload paperglee-v0.5.zip to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

What is Paperglee?
Paperglee is a WordPress Plugin for paper.li

How does Paperglee work?
Paperglee works by harnessing the incredible power of the more than 250 million pieces of content published by paper.li everyday, and converting that to posts that can be automatically shared on popular social media, including Twitter, Facebook, LinkedIn, and Pinterest.

What does Paperglee do that paper.li alone does not?
Paperglee lets you post directly to your own web site, in your WordPress theme, beside your calls to action. You can schedule posts for whenever you want, and as often as you want. With Paperglee, you can also create custom content categories and unique web urls at yourname.com You can even add keywords and tags to help search engines find your content, and highlight your best content.

Is Paperglee hard to use?	
Nope! Just install and paste in the web address of any paper.li to add a subscription. Add as many subscriptions as you want! You will be up and running in less than 5 minutes!

Will Paperglee look different than the rest of my web site?
Nope! Paperglee is built to automatically integrate with your unique WordPress theme. It will look, act and feel exactly like the rest of your web site. It is even fully responsive, meaning Paperglee looks and performs great on smartphones, tablets and other mobile devices.

Do I need any special knowledge, like software developing, to use Paperglee?
Nope! Paperglee is plug and play so you are a content marketing machine from the moment you add your first subscription. Of course, if you want to customize your version of Paperglee, you are free to do so. A lot of our customers find unique ways to use Paperglee.

Will Paperglee work with my web site analytics?
Yep! Paperglee is designed to work right away with the most popular analytics packages, including Google Analytics. If you have your web site connected to a CRM, like Salesforce, Paperglee will even work with that!

== Changelog ==

* We will List versions from most recent at top to oldest at bottom.

== Upgrade Notice ==

* We will provide upgrade notices here