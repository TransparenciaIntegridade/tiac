<?php

require_once 'Twig/Autoloader.php';

define( 'PAPERGLEE_UUID_PATTERN', '/[[:xdigit:]]{8}-[[:xdigit:]]{4}-[[:xdigit:]]{4}-[[:xdigit:]]{4}-[[:xdigit:]]{12}/' );

add_action( 'init', 'paperglee_init_templating' );

add_filter( PAPERGLEE_FILTER_CONTENT, 'paperglee_default_content', 10, 2 );

function paperglee_init_templating() {
	Twig_Autoloader::register();
}

function paperglee_update_hook() {
	$subscriptions = get_option( PAPERGLEE_SUBSCRIPTIONS );
	foreach( $subscriptions as $id ) {
		paperglee_update_paper( $id );
	}
}

function paperglee_update_paper( $paper_id, $version = null ) {
	$data = paperglee_retrieve_paper( $paper_id, $version );

	$paper = $data->paper;
	$edition = $data->edition;
	$sections = $edition->sections;

	$articles = array();
	foreach($edition->headlines as $article) {
		if(isset( $articles[$article->id] )) {
			continue;
		}
		$articles[] = $article;
	}

	foreach($edition->main_articles as $section) {
		foreach($section->articles as $article) {
			if(isset($articles[$article->id])) {
				continue;
			}
			$articles[] = $article;
		}
	}

	$keys = array();
	foreach($articles as $article_id => $article) {
		$post_id = paperglee_insert_article($paper_id, $article);
		if( $post_id && get_post_meta( $post_id, PAPERLI_DUPLICATE ) !== true ) {
			$keys[] = $post_id;
		}
	}

	$opt = get_option( PAPERGLEE_PUBLISHING );
	if( isset($opt[PAPERGLEE_OPT_AUTO_SCHEDULE]) && $opt[PAPERGLEE_OPT_AUTO_SCHEDULE] ) {
		paperglee_schedule( time(), $paper->next_edition, $keys );
	}
}

function paperglee_insert_article( $paper_id, $article ) {
	$post_id = paperglee_get_by_article_id( $article->id );

	// The post is already in the DB
	if( !empty( $post_id ) ) {
		error_log( "Paperglee: $post_id is already in the database" );
		return false;
	}

	$opt = get_option( PAPERGLEE_PUBLISHING );
	$post = array(
		'comment_status' => 'closed',
		'ping_status' => 'closed',
		'post_title' => $article->title,
		'post_status' => 'draft',
		'post_type' => PAPERLI_POST_TYPE,
		'post_content' => apply_filters( PAPERGLEE_FILTER_CONTENT, '', $article ),
	);

	$url = parse_url( $article->url );
	$url = $url['host'].$url['path'];

	$dup_key = PAPERLI_DUPLICATE . md5($url);
	$is_dup = get_transient( $dup_key );
	if(!$is_dup) {
		// TODO: The black out period on duplicates should be configurable
		set_transient( $dup_key, true, 30 * DAY_IN_SECONDS );
	}

	$post_id = wp_insert_post($post);

	add_post_meta( $post_id, PAPERLI_META_KEY, $article->id, true );
	add_post_meta( $post_id, PAPERLI_PAPER_KEY, $paper_id, true );
	add_post_meta( $post_id, PAPERLI_ARTICLE, $article, true);

	if($is_dup) {
		error_log( "Paperglee: $post_id is a duplicate of an existing post" );
		add_post_meta( $post_id, PAPERLI_DUPLICATE, true, true);
	}

	return $post_id;
}

function paperglee_schedule( $start, $end, $ids ) {
	if(empty($ids)) {
		return;
	}

	$day = date( 'w', $start );
	$opt = get_option( PAPERGLEE_PUBLISHING );
	$randomize = isset($opt[PAPERGLEE_OPT_RANDOMIZE]) && $opt[PAPERGLEE_OPT_RANDOMIZE];

	$interval = abs( $end - $start );
	$interval = $interval / (count( $ids ) + 1);

	$publish = $start + $interval;
	foreach($ids as $id) {
		$date = $publish;
		if($randomize) {
			$date = $date + rand(-$interval / 2, $interval / 2);
		}
		$update = array(
			'ID' => $id,
			'post_status' => 'future',
			'edit_date' => true,
			'post_date' => date( 'Y-m-d H:i:s', $publish ),
			'post_date_gmt' => gmdate( 'Y-m-d H:i:s', $publish ),
		);
		error_log(var_export($update, true));
		wp_update_post( $update );
		$publish = $publish + $interval;
	}
}

function paperglee_retrieve_paper( $id, $version = null ) {
	$key = "paperli_$id";

	// Retrieve paper from cache
	$data = get_transient( $key );
	
	if( !($data === false) ) {
		return json_decode( $data ); // If the data is live in the cache then no need to do anything
	}

	$params = array(
		'id' => $id,
		'ver' => empty( $version ) ? 'full' : $version,
	);

	$url = 'http://paper.li/~api/papers/lookup?'.http_build_query( $params );
	$json = json_decode( wp_remote_retrieve_body( wp_remote_get( $url ) ), false );

	if($json->status !== 200) {
		error_log( "Paperglee: Request for '$url' failed with status code ${$json->status}" );
		return false;
	}

	$data = $json->data;
	$data->paper->next_edition = date( 'U', strtotime( $data->paper->next_edition ) );
	$expiration = max( 1, $data->paper->next_edition - time() );

	// Cache the content until the next edition of the paper is available
	set_transient( $key, json_encode( $data ), $expiration );
	return $data;
}

function paperglee_default_content( $content, $article ) {
	$loader = new Twig_Loader_String();
	$twig = new Twig_Environment($loader);

	$template = get_option( PAPERGLEE_TEMPLATE );
	$parameters = array( 'article' => $article );

	return $twig->render( $template, $parameters );
}

?>