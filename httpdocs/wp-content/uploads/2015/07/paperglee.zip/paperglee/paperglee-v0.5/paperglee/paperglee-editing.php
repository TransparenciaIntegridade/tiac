<?php

add_action( 'admin_init', 'paperglee_add_meta_box' );

function paperglee_sticky_meta() {
?>
	<input id="paperglee-sticky" name="sticky" type="checkbox" value="sticky" <?php checked( is_sticky() ); ?> />
	<label for="paperglee-sticky" class="selectit"><?php _e( 'Make an Editor\'s choice' ) ?></label>
<?php
}

function paperglee_add_meta_box() {
	if( !current_user_can( 'edit_others_posts' ) ) {
		return;
	}

	add_meta_box( 'paperglee_sticky_meta', __( 'Editor\'s Choice' ), 'paperglee_sticky_meta', PAPERLI_POST_TYPE, 'side', 'high' );
}

?>