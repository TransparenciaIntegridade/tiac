<?php
/*
Plugin Name: Paperglee
Plugin URI: http://paperglee.com
Version: 0.5
Author: Paperglee
Author URI: http://paperglee.com
Description: Paperglee posts content from paper.li directly into your WP theme to create SEO-rich links on your web site. Schedule posts whenever you want! Includes de-duplication of content and cool developer tools!
*/

define( 'PAPERGLEE_DOMAIN', 'paperglee' );
define( 'PAPERGLEE_SUBSCRIPTIONS', 'paperglee_subscriptions' );
define( 'PAPERGLEE_PUBLISHING', 'paperglee_publishing' );
define( 'PAPERGLEE_TEMPLATE', 'paperglee_template' );

define( 'PAPERLI_DUPLICATE', 'paperli_duplicate' );
define( 'PAPERLI_ARTICLE', 'paperli_article' );
define( 'PAPERLI_META_KEY', 'paperli_article_id' );
define( 'PAPERLI_PAPER_KEY', 'paperli_paper_id' );
define( 'PAPERLI_POST_TYPE', 'paperli' );

define( 'PAPERGLEE_STATUS_DUPLICATE', 'paperglee_duplicate' );

define( 'PAPERGLEE_SCHEDULE', 'paperglee_schedule' );
define( 'PAPERGLEE_UPDATE_INTERVAL', 3600 );

define( 'PAPERGLEE_UPDATE_ACTION', 'paperglee_update' );

define( 'PAPERGLEE_NONCE_NAME', 'paperglee_nonce' );

define( 'PAPERGLEE_OPT_RANDOMIZE', 'randomize' );
define( 'PAPERGLEE_OPT_AUTO_SCHEDULE', 'auto_schedule' );
define( 'PAPERGLEE_OPT_FEEDS', 'feeds' );

define( 'PAPERGLEE_OPT_DUPLICATES_REMOVE', 'remove_duplicates' );

define( 'PAPERGLEE_OPT_TEMPLATE', 'template' );

define( 'PAPERGLEE_ACTION_SUBSCRIBE', 'paperglee_subscribe' );
define( 'PAPERGLEE_ACTION_UNSUBSCRIBE', 'paperglee_unsubscribe' );

define( 'PAPERGLEE_FILTER_DUPLICATE', 'paperglee_duplicate' );
define( 'PAPERGLEE_FILTER_CONTENT', 'paperglee_content' );

add_action( 'init', 'paperglee_init' );
add_action( 'wp_enqueue_scripts', 'paperglee_enqueue_dependencies' );

add_action( PAPERGLEE_UPDATE_ACTION, 'paperglee_update_hook' );

register_activation_hook( __FILE__, 'paperglee_activation_hook' );
register_deactivation_hook( __FILE__, 'paperglee_deactivation_hook' );

add_filter( 'cron_schedules', 'paperglee_cron_schedule' );
add_filter( 'widget_posts_args', 'paperglee_recent_posts_widget' );

function paperglee_init() {
	register_post_type( PAPERLI_POST_TYPE, array(
		'labels' => array(
			'name' => 'Paperglee',
			'singular_name' => 'Paperglee',
		),
		'public' => true,
		'has_archive' => true,
		'query_var' => PAPERLI_POST_TYPE,
		'rewrite' => array( 'slug' => PAPERLI_POST_TYPE ),
		'taxonomies' => array( 'category', 'post_tag' ),
	) );
	register_post_status( PAPERGLEE_STATUS_DUPLICATE, array(
		'label' => 'Duplicate',
		'public' => false,
		'exclude_from_search' => true,
		'label_count' => _n_noop( 'Duplicate <span class="count">(%s)</span>', 'Duplicates <span class="count">(%s)</span>' )
	) );

	add_action( 'pre_get_posts', 'paperglee_post_types_to_query' );
}

function paperglee_enqueue_dependencies() {
}

function paperglee_activation_hook() {
	wp_clear_scheduled_hook( PAPERGLEE_UPDATE_ACTION );
	wp_schedule_event( 0, 'hourly' /* PAPERLI_SCHEDULE */, PAPERGLEE_UPDATE_ACTION );

	$opt = get_option( PAPERGLEE_SUBSCRIPTIONS );
	if( $opt === false ) {
		update_option( PAPERGLEE_SUBSCRIPTIONS, array() );
	}
	$opt = get_option( PAPERGLEE_TEMPLATE );
	if( $opt === false ) {
		$dir_templates = plugin_dir_path( __FILE__ ) . 'templates/';
		update_option( PAPERGLEE_TEMPLATE, file_get_contents( $dir_templates.'Default' ) );
	}
}

function paperglee_deactivation_hook() {
	wp_clear_scheduled_hook( PAPERGLEE_UPDATE_ACTION );
}

function paperglee_cron_schedule($schedules) {
	$schedules[PAPERGLEE_SCHEDULE] = array(
 		'interval' => PAPERGLEE_UPDATE_INTERVAL,
 		'display' => __( 'Paperglee Update' )
 	);
 	return $schedules;
}

// Given one or more post types add the paperglee type if the right conditions are met
function paperglee_inject($post_types = null) {
	if( empty( $post_types ) ) {
		$post_types = array( 'post' );
	}
	else if( is_string( $post_types ) ) {
		$post_types = array( $post_types );
	}
	else if( !is_array( $post_types ) ) {
		return $post_types;
	}

	$opt = get_option( PAPERGLEE_PUBLISHING );
	$matching = array_intersect( $post_types, $opt[PAPERGLEE_OPT_FEEDS] );

	if( !empty( $matching ) ) {
		$post_types[] = PAPERLI_POST_TYPE;
	}

	return $post_types;
}

function paperglee_recent_posts_widget($args) {
	if( !isset( $args[ 'post_type' ] ) ) {
		$args[ 'post_type' ] = null;
	}
	$args[ 'post_type' ] = paperglee_inject( $args[ 'post_type' ] );

	return $args;
}

function paperglee_post_types_to_query($query) {
	if ( $query->is_singular || !$query->is_main_query() || $query->is_admin ) {
		return $query;
	}

	$query->set( 'post_type', paperglee_inject( $query->get( 'post_type' ) ) );

	return $query;
}

require 'paperglee-api.php';
require 'paperglee-bot.php';
require 'paperglee-ajax.php';
require 'paperglee-editing.php';
require 'paperglee-subscriptions.php';
require 'paperglee-template.php';
require 'paperglee-publishing.php';

?>