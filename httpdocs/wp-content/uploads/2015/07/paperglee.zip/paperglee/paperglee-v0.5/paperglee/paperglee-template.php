<?php
add_action('admin_init', 'paperli_template_init');
add_action('admin_menu', 'paperli_template_menu');

define( 'PAPERGLEE_SLUG_TEMPLATE', 'paperli_template' );

function paperli_template_init() {
	register_setting( PAPERGLEE_TEMPLATE, PAPERGLEE_TEMPLATE, 'paperglee_template_options_validate' );
}

function paperli_template_menu() {
	$page_hook = add_submenu_page( 'edit.php?post_type='.PAPERLI_POST_TYPE,
		'Paper.li Template', 'Template', 'manage_options', PAPERGLEE_SLUG_TEMPLATE, 'paperli_template_page' );

	add_settings_section( 'paperglee_template_template', __( 'Template', PAPERGLEE_DOMAIN ), 'paperli_template_section', 
PAPERGLEE_TEMPLATE );

	add_action( 'admin_print_scripts-' . $page_hook, 'paperglee_template_scripts');
}

function paperglee_template_scripts() {
	wp_enqueue_script( 'jquery-linedtextarea', plugins_url( '/js/jquery-linedtextarea.js', __FILE__ ), array( 'jquery' ) );

	wp_enqueue_style( 'jquery-linedtextarea', plugins_url( '/css/jquery-linedtextarea.css', __FILE__) );
}

function paperli_template_section() {
	$loader = new Twig_Loader_String();
	$twig = new Twig_Environment($loader);

	$template = get_option(PAPERGLEE_TEMPLATE);

	try {
		$twig->parse($twig->tokenize($template));
	} catch (Twig_Error_Syntax $e) {
		?><div class="error"><p>Line <?php echo $e->getTemplateLine(); ?>: <?php echo $e->getMessage(); ?></p></div><?php
	}

	?>
	<textarea id="paperglee-template" cols="120" rows="20" name="<?php echo PAPERGLEE_TEMPLATE; ?>"><?php echo $template; ?></textarea>
	<script>
		jQuery(function() {jQuery("#paperglee-template").linedtextarea();});
	</script>
	<?php
}

function paperli_template_page() {
	$opt = get_option( PAPERGLEE_PUBLISHING );
?>
<div class="wrap">
<!-- <?php echo var_dump($opt); ?> -->
<h2><?php _e( 'Paper.li Template', PAPERGLEE_DOMAIN ); ?></h2>
	<form method="post" action="options.php">
	<?php
		settings_fields( PAPERGLEE_TEMPLATE );
		do_settings_sections( PAPERGLEE_TEMPLATE );
		submit_button();
	?>
	</form>
</div>
<?php
}

function paperglee_template_options_validate($opt) {
	return $opt;
}

?>