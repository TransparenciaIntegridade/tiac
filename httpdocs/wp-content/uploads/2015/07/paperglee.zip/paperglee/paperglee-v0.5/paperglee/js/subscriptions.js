(function ($) {
	"use strict";
	function paperglee_remove(id) {
		Paperglee.unsubscribe(id)
			.done(function() {
				$("#" + id).detach().remove();
			});
	}
	function paperglee_add(subscription) {
		if(subscription == null || subscription === undefined) {
			return;
		}

		var next_edition = new Date(1000 * parseInt(subscription['next_edition'], 10));
		$('<tr>', { "id": subscription["id"] }).appendTo("tbody#paperglee-papers")
			.append($('<th><a href=\"http://paper.li' + subscription["path"] + '">' + subscription["title"] + '</a></th>'))
	  		.append($('<td>' + next_edition.toLocaleString() + '</td>'))
			.append($('<td>' + subscription['description'] + '</td>'))
			.append($('<td>')
				.append($('<input type="button" value="Unsubscribe">')
					.bind('click', subscription["id"], function(evt) {paperglee_remove(evt.data);})))
	}
	function paperglee_subscribe(id) {
		Paperglee.subscribe(id)
			.done(function(paper) {paperglee_add(paper);})
			.fail(function() {console.log('Fail');})
			;
	}

	$(function () {
		$("input#paperglee-add").bind("click", function () {
			var id = $("#paperglee-id").val();
			paperglee_subscribe(id);
		});
		$("a.paperglee-remove").bind("click", paperglee_remove);

		Paperglee.subscriptions()
			.done(function(subscriptions) {
				for(var n = 0; n < subscriptions.length; ++n) {
					paperglee_add(subscriptions[n]);
				}
			});
	});
})(jQuery);