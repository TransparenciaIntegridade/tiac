<?php

add_action('admin_init', 'paperli_publishing_init');
add_action('admin_menu', 'paperli_publishing_menu');

define( 'PAPERGLEE_SLUG_PUBLISHING', 'paperli_publishing' );

function paperli_publishing_init() {
	register_setting( PAPERGLEE_PUBLISHING, PAPERGLEE_PUBLISHING, 'paperglee_publishing_options_validate' );
}

function paperli_publishing_menu() {
	$opt = get_option( PAPERGLEE_PUBLISHING );

	add_submenu_page( 'edit.php?post_type='.PAPERLI_POST_TYPE,
		'Paper.li Publishing', 'Publishing', 'manage_options', PAPERGLEE_SLUG_PUBLISHING, 'paperli_publishing_page' );

	add_settings_section( 'paperglee_publishing_feed', __( 'Feed', PAPERGLEE_DOMAIN ), 'paperglee_publishing_feed', 
PAPERGLEE_PUBLISHING );

	add_settings_field( 'paperglee_publishing_post_types', __( 'Include in feeds', PAPERGLEE_DOMAIN ), 'paperglee_publishing_post_types', PAPERGLEE_PUBLISHING, 'paperglee_publishing_feed' );

	add_settings_section( 'paperglee_publishing_schedule', __( 'Schedule', PAPERGLEE_DOMAIN ), 'paperglee_publishing_schedule', PAPERGLEE_PUBLISHING );

	add_settings_field( 'paperglee_publishing_auto_schedule', __( 'Autopublish', PAPERGLEE_DOMAIN ), 'paperglee_publishing_auto_schedule', PAPERGLEE_PUBLISHING, 'paperglee_publishing_schedule' );
	add_settings_field( 'paperglee_publishing_randomize', __( 'Randomize', PAPERGLEE_DOMAIN ), 'paperglee_publishing_randomize', PAPERGLEE_PUBLISHING, 'paperglee_publishing_schedule' );

	add_settings_section( 'paperglee_publishing_duplicates', __( 'Duplicates', PAPERGLEE_DOMAIN ), 'paperglee_publishing_duplicates', PAPERGLEE_PUBLISHING );

	add_settings_field( 'paperglee_publishing_duplicate_remove', __( 'Flag', PAPERGLEE_DOMAIN ), 'paperglee_publishing_duplicate_remove', PAPERGLEE_PUBLISHING, 'paperglee_publishing_duplicates' );
}

function paperglee_publishing_feed() {
}

function paperglee_publishing_post_types() {
	$opt = get_option( PAPERGLEE_PUBLISHING );

	if( empty( $opt[PAPERGLEE_OPT_FEEDS] ) ) {
		$opt[PAPERGLEE_OPT_FEEDS] = array();
	}

	$post_types = get_post_types(array(
		'publicly_queryable' => true,
	));
	foreach($post_types as $post_type) {
		if( $post_type === PAPERLI_POST_TYPE ) {
			continue;
		}
		$pt = get_post_type_object( $post_type );
?>
		<input type="checkbox" name="<?php echo PAPERGLEE_PUBLISHING; ?>[post_types][<?php echo $post_type;?>]" value="<?php echo $post_type; ?>" <?php if(in_array($post_type, $opt['feeds'])) {echo 'checked';} ?>><?php echo $pt->labels->name; ?></input><br>
<?php
	}
}

function paperglee_publishing_schedule() {
}

function paperglee_publishing_auto_schedule() {
	$opt = get_option( PAPERGLEE_PUBLISHING );
?>
	<input type="checkbox" name="<?php echo PAPERGLEE_PUBLISHING; ?>[<?php echo PAPERGLEE_OPT_AUTO_SCHEDULE; ?>]" <?php if($opt[PAPERGLEE_OPT_AUTO_SCHEDULE]) {echo 'checked';} ?>></input>
<?php
}

function paperglee_publishing_randomize() {
	$opt = get_option( PAPERGLEE_PUBLISHING );
?>
	<input type="checkbox" name="<?php echo PAPERGLEE_PUBLISHING; ?>[<?php echo PAPERGLEE_OPT_RANDOMIZE; ?>]" <?php if($opt[PAPERGLEE_OPT_RANDOMIZE]) {echo 'checked';} ?>></input>
<?php
}

function paperglee_publishing_duplicates() {
}

function paperglee_publishing_duplicate_remove() {
	$opt = get_option( PAPERGLEE_PUBLISHING );

	?>
	<input type="checkbox" name="<?php echo PAPERGLEE_PUBLISHING; ?>[<?php echo PAPERGLEE_OPT_DUPLICATES_REMOVE; ?>]" <?php if($opt[PAPERGLEE_OPT_DUPLICATES_REMOVE]) {echo 'checked';} ?>></input>
<?php
}

function paperli_publishing_page() {
	$opt = get_option( PAPERGLEE_PUBLISHING );
?>
<div class="wrap">
<!-- <?php echo var_dump($opt); ?> -->
<h2><?php _e( 'Paper.li Publishing', PAPERGLEE_DOMAIN ); ?></h2>
	<form method="post" action="options.php">
	<?php
		settings_fields( PAPERGLEE_PUBLISHING );
		do_settings_sections( PAPERGLEE_PUBLISHING );
		submit_button();
	?>
	</form>
</div>
<?php
}

function paperglee_publishing_options_validate( $opt ) {
	$post_types = $opt['post_types'];
	unset( $opt['post_types'] );

	if( empty($post_types) ) {
		$post_types = array();
	}

	$opt[PAPERGLEE_OPT_FEEDS] = array();
	foreach($post_types as $post_type) {
		$opt['feeds'][] = $post_type;
	}

	$opt[PAPERGLEE_OPT_AUTO_SCHEDULE] = ($opt[PAPERGLEE_OPT_AUTO_SCHEDULE] === 'on');
	$opt[PAPERGLEE_OPT_RANDOMIZE] = ($opt[PAPERGLEE_OPT_RANDOMIZE] === 'on');
	$opt[PAPERGLEE_OPT_DUPLICATES_REMOVE] = ($opt[PAPERGLEE_OPT_DUPLICATES_REMOVE] === 'on');

	return $opt;
}