<?php

add_action('admin_menu', 'paperli_subscriptions_menu');

define( 'PAPERLI_SLUG_SUBSCRIPTIONS', 'paperli_subscriptions' );

function paperli_subscriptions_menu() {
	$page_hook = add_submenu_page( 'edit.php?post_type='.PAPERLI_POST_TYPE,
		'Paper.li Subscriptions', 'Subscriptions', 'manage_options', PAPERLI_SLUG_SUBSCRIPTIONS, 'paperli_subscriptions_page'
		);
	add_action( 'admin_print_scripts-' . $page_hook, 'paperglee_subscription_scripts');
}

function paperli_subscriptions_page() {
?>
<div class="wrap">
<h2><?php _e( 'Paper.li Subscriptions' ); ?></h2>
	<div class="tablenav top">
		<input type="text" id="paperglee-id"></input>
		<input type="button" id="paperglee-add" value="<?php _e( 'Add Subscription', PAPERGLEE_DOMAIN ); ?>" class="button"></input>
	</div>
	<table class="wp-list-table widefat fixed">
		<thead>
			<th>Title</th>
			<th>Next Edition</th>
			<th>Description</th>
			<td></td>
		</thead>
		<tfoot>
			<th>Title</th>
			<th>Next Edition</th>
			<th>Description</th>
			<td></td>
		</tfoot>
		<tbody id="paperglee-papers"></tbody>
	</table>
</div>
<?php
}

function paperglee_subscription_scripts() {
	wp_enqueue_script( 'paperglee-subscriptions', plugins_url( '/js/subscriptions.js', __FILE__ ), array( 'jquery' ) );
}
?>