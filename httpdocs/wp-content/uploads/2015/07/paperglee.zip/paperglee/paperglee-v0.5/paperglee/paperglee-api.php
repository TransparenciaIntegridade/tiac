<?php
function paperglee_get_by_article_id( $id ) {
	global $wpdb;
	$sql = "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '%s' AND meta_value = '%s'";
	return $wpdb->get_var( $wpdb->prepare( $sql, PAPERLI_META_KEY, $id ) );
}

function paperglee_subscribe( $context ) {
	$id = paperglee_retrieve_paper_id( $context );
	if( empty( $id ) ) {
		error_log("Paperglee: '$context' is not a valid paper.li paper");
		return false;
	}

	$paper = paperglee_retrieve_paper( $id );
	if( empty( $paper ) ) {
		error_log( "Paperglee: Failed to retrieve paper with id '$id'" );
		return false;
	}

	$subscriptions = get_option( PAPERGLEE_SUBSCRIPTIONS, array() );

	if( !in_array( $id, $subscriptions ) ) {
		$subscriptions[] = $id;
		update_option( PAPERGLEE_SUBSCRIPTIONS, $subscriptions );
		do_action( PAPERGLEE_ACTION_SUBSCRIBE, $id );
	}

	return $paper->paper;
}

function paperglee_unsubscribe( $id ) {
	$id = paperglee_retrieve_paper_id( $id );
	if( empty( $id ) ) {
		return false;
	}

	$subscriptions = get_option( PAPERGLEE_SUBSCRIPTIONS, array() );
	$index = array_search( $id, $subscriptions );

	if( $index === false ) {
		return false;
	}

	unset($subscriptions[$index]);
	update_option( PAPERGLEE_SUBSCRIPTIONS, $subscriptions );
	do_action( PAPERGLEE_ACTION_UNSUBSCRIBE, $id );

	return true;
}

// Attempt to find the id of a paper given a URL or a UUID
function paperglee_retrieve_paper_id($id) {
	$id = trim($id);
	if(preg_match(PAPERGLEE_UUID_PATTERN, $id) === 1) {
		return $id;
	}

	$url = filter_var($id, FILTER_VALIDATE_URL);
	if(!empty($url)) {
		$host = parse_url($url, PHP_URL_HOST);
		if($host !== 'paper.li') {
			return false;
		}

		$response = wp_remote_get($url);
		$response_code = wp_remote_retrieve_response_code($response);
		if($response_code !== 200) {
			return false;
		}
		preg_match_all(PAPERGLEE_UUID_PATTERN, wp_remote_retrieve_body($response), $matches);

		$id = $matches[0][0];
		set_transient($url_key, $id);

		return $id;
	}

	return false;
}
?>