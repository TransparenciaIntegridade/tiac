var Paperglee = (function($, undefined) {
	function ajax_request(action, data) {
		if(typeof data == "undefined") {
			data = {};
		}
		data['action'] = action;
		data['nonce'] = paperglee.nonce;

		return $.post(paperglee.ajaxurl, data);
	}
	return {
		'subscriptions': function() {
			return ajax_request('paperglee_subscriptions');
		},
		'subscribe': function(id) {
			return ajax_request('paperglee_subscribe', {id: id});
		},
		'unsubscribe': function(id) {
			return ajax_request('paperglee_unsubscribe', {id: id});
		}
	};
})(jQuery);