<?php
add_action( 'admin_enqueue_scripts', 'paperglee_admin_enqueue_scripts' );

add_action( 'wp_ajax_paperglee_subscriptions', 'ajax_paperglee_subscriptions' );
add_action( 'wp_ajax_paperglee_subscribe', 'ajax_paperglee_subscribe' );
add_action( 'wp_ajax_paperglee_unsubscribe', 'ajax_paperglee_unsubscribe' );

function paperglee_admin_enqueue_scripts() {
	wp_enqueue_script( 'paperglee-ajax', plugins_url( '/js/ajax.js', __FILE__ ), array( 'jquery' ) );
	wp_enqueue_style( 'paperglee-admin-css', plugins_url( '/css/admin.css', __FILE__ ) );

	$namespace = array(
		'ajaxurl' => admin_url( 'admin-ajax.php' ),
		'nonce' => wp_create_nonce( PAPERGLEE_NONCE_NAME ),
	);

	wp_localize_script( 'paperglee-ajax', 'paperglee', $namespace );
}

function ajax_paperglee_subscriptions() {
	ajax_paperglee_check_privileges();

	$subscriptions = get_option( PAPERGLEE_SUBSCRIPTIONS );

	$papers = array();
	header("HTTP/1.1 200 OK");
	header( 'Content-Type: application/json' );
	foreach( $subscriptions as $paper ) {
		$content = paperglee_retrieve_paper( $paper );
		$papers[] = $content->paper;
	}

	echo json_encode( $papers );

	exit;
}

function ajax_paperglee_subscribe() {
	ajax_paperglee_check_privileges();

	$paper = paperglee_subscribe( $_REQUEST['id'] );
	if( empty( $paper) ) {
		header("HTTP/1.0 404 Not Found");
	} else {
		header( 'Content-Type: application/json' );
		echo json_encode( $paper );
	}

	exit;
}

function ajax_paperglee_unsubscribe() {
	ajax_paperglee_check_privileges();

	if( paperglee_unsubscribe( $_REQUEST['id'] ) ) {
		header("HTTP/1.0 200 OK");
	}
	else {
		header("HTTP/1.0 404 Not Found");
	}

	exit;
}

function ajax_paperglee_check_privileges() {
	$nonce = $_REQUEST['nonce'];
	if ( !wp_verify_nonce( $nonce, PAPERGLEE_NONCE_NAME ) ) {
		error_log( "Paperglee: Failed to verify ajax nonce" );
		header("HTTP/1.0 403 Forbidden");
		exit;
	}
	if( !current_user_can( 'manage_options' ) ) {
		error_log( "Paperglee: User does not have sufficient privileges" );
		header("HTTP/1.0 403 Forbidden");
		exit;
	}
}

?>